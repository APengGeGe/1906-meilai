const state = {          // 组件间共享的数据
  list1:0,
  username:''
}

export default state;
