const getters= {
    gets(state){
        return "你好"+state.list1
    },
    gets(state){
      return state.username
  },
}

export default getters;
