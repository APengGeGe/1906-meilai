const  modules= {
    info:{
      state:{
          apeng:6666
      },
      getters: {
          apeng1(state){
              return state.apeng+"gege"
          }
      },
      mutations: {

      },
      actions: {

      },
      modules: {

      }
    }
}

export default modules;



